package com.rest.spring.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.rest.spring.dao.EmpDao;
import com.rest.spring.model.Employee;

/**
 * Handles requests for the Employee service.
 */
@Controller
public class EmployeeController {
	@Autowired
	EmpDao dao;// will inject dao from xml file

	public final static long MILLIS_PER_DAY = 24 * 60 * 60 * 1000L;
	private static final Logger logger = LoggerFactory
			.getLogger(EmployeeController.class);

	@RequestMapping(value = EmpRestURIConstants.CREATE_EMP, method = RequestMethod.GET, headers = "Accept=application/xml")
	public @ResponseBody
	Employee getDummyEmployee() throws ParseException {
		logger.info("Start getDummyEmployee");
		Employee emp = new Employee();
		String empJoiningDate = "2009-09-10";
		Date currentDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date date1 = sdf.parse(empJoiningDate);
		Date date2 = sdf.parse(sdf.format(currentDate));

		boolean moreThanDay = Math.abs(date1.getTime() - date2.getTime()) > MILLIS_PER_DAY;
		if (moreThanDay == false) {
			logger.info("employee details already in data base");
		} else {
			emp.setEmpJoinDate(empJoiningDate);
		}
		int result = 0;
		emp.setId(1);
		emp.setName("CTS");
		emp.setDepartment("CS");
		result = dao.save(emp);
		return emp;
	}

	@RequestMapping(value = EmpRestURIConstants.GET_EMP, method = RequestMethod.GET, headers = "Accept=application/xml")
	public @ResponseBody
	Employee getEmployee(@PathVariable("id") int empId) {
		logger.info("Start getEmployee. ID=" + empId);
		Employee emp = new Employee();
		emp = dao.getEmpById(empId);
		return emp;
	}

	@RequestMapping(value = EmpRestURIConstants.GET_ALL_EMP, method = RequestMethod.GET)
	public @ResponseBody
	List<Employee> getAllEmployees() {
		logger.info("Start getAllEmployees.");
		List<Employee> emps = new ArrayList<Employee>();
		emps = dao.getEmployees();
		return emps;
	}

	@RequestMapping(value = EmpRestURIConstants.DELETE_EMP, method = RequestMethod.PUT, headers = "Accept=application/xml")
	public @ResponseBody
	int deleteEmployee(@PathVariable("id") int empId) {
		logger.info("Start deleteEmployee.");
		int emp = 0;
		emp = dao.delete(empId);
		return emp;
	}

}
