package com.memorynotfound.xml.xsd;

public class ValidateXmlXsd {

    public static String xml =
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
            "<course id=\"1ds\">\n" +
            "    <name>JAX-B</name>\n" +
            "    <department>2</department>\n" +
            "</course>";

    public static void main(String... args) {
        try {
            System.out.println("Validate XML against XSD Schema");
            XsdValidator validator = new XsdValidator("/schema.xsd");
            validator.validate(xml);
            System.out.println("Validation is successful");
        } catch (XsdValidationException e) {
            System.out.println("Error validation: " + e.getMessage());
        }
    }
}
