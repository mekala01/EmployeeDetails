package com.memorynotfound.xml.xsd;

public class XsdValidationException extends Exception {
    public XsdValidationException(String message) {
        super(message);
    }

    public XsdValidationException(Throwable cause) {
        super(cause);
    }
}
