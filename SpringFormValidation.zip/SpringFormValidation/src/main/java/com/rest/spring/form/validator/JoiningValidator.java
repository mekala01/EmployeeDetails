package com.rest.spring.form.validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class JoiningValidator implements ConstraintValidator<JoiningDate, String> {
	public final static long MILLIS_PER_DAY = 24 * 60 * 60 * 1000L;

	@Override
	public void initialize(JoiningDate paramA) {
	}

	@Override
	public boolean isValid(String JoiningDate, ConstraintValidatorContext ctx) {
		if(JoiningDate == null){
			return false;
		}
		Date currentDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Date date1 = new Date();
		try {
			date1 = sdf.parse(JoiningDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Date date2 = new Date();
		try {
			date2 = sdf.parse(sdf.format(currentDate));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		boolean moreThanDay = Math.abs(date1.getTime() - date2.getTime()) > MILLIS_PER_DAY;
		if (moreThanDay == false) {
			return false;
			
		} else {
			return true;
		}
	}

}
